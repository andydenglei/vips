This is the old vips7 C++ API. Use the vips8 one in preference for new
projects.

