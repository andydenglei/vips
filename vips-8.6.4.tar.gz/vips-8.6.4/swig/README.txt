This is the old vips7 Python binding. Use the vips8 one in preference for new
projects. 

